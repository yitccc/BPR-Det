from ultralytics import RTDETR
import warnings
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np
import os

warnings.filterwarnings('ignore')

# Global variables to store the values for each epoch
cov_history_head = []
cov_history_tail = []


def on_train_epoch_end(trainer):
    """Extract the mean of Sigma for the current epoch."""
    pt_model = trainer.model.module if hasattr(trainer.model, 'module') else trainer.model

    try:
        with torch.no_grad():
            # 1. Get the last layer (the entire RTDETRDecoder module)
            decoder_layer = pt_model.model[-1]

            # 2. Get the last classification head (TCLMoEHead) from dec_score_head (ModuleList)
            last_tcl_head = decoder_layer.dec_score_head[-1]

            # 3. Extract the Sigma parameters (Note: 'S' is capitalized in the source code)
            sigma_head_param = last_tcl_head.Sigma_head
            sigma_tail_param = last_tcl_head.Sigma_tail

            # 4. Calculate the mean after applying softplus
            import torch.nn.functional as F
            mean_s_head = F.softplus(sigma_head_param).mean().item()
            mean_s_tail = F.softplus(sigma_tail_param).mean().item()

            cov_history_head.append(mean_s_head)
            cov_history_tail.append(mean_s_tail)

            # Print for monitoring
            print(
                f"\n[TCL MoE Tracker] Epoch {trainer.epoch + 1}: Sigma_head = {mean_s_head:.4f}, Sigma_tail = {mean_s_tail:.4f}")

    except Exception as e:
        if trainer.epoch == 0:
            print(f"\n[Warning] Failed to extract Sigma parameters! Error: {e}")


# ==========================================
# Define callback function: Execute automatically when training ends
# ==========================================
def on_train_end(trainer):
    """Automatically plot and save to the corresponding runs directory after training."""
    if len(cov_history_head) == 0:
        return

    print("\nTraining finished. Plotting covariance dynamics...")
    epochs_arr = np.arange(1, len(cov_history_head) + 1)

    plt.figure(figsize=(6, 4.5))
    plt.plot(epochs_arr, cov_history_head, label=r'$\Sigma_{head}$ Mean',
             color='#1f77b4', linewidth=2.5, linestyle='-', alpha=0.9)
    plt.plot(epochs_arr, cov_history_tail, label=r'$\Sigma_{tail}$ Mean',
             color='#ff7f0e', linewidth=2.5, linestyle='-', alpha=0.9)

    plt.xlabel('Training Epochs', fontsize=12, fontweight='bold')
    plt.ylabel('Mean of Diagonal Covariance', fontsize=12, fontweight='bold')
    plt.title('Training Dynamics of Uncertainty Covariance', fontsize=13)

    plt.legend(loc='upper right', fontsize=11, framealpha=0.9)
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()

    # Seamlessly integrate with Ultralytics: Save the PDF in the runs/detect/trainX folder of this training session
    save_path = os.path.join(trainer.save_dir, 'covariance_dynamics.pdf')
    plt.savefig(save_path, format='pdf', bbox_inches='tight')
    print(f"Plot saved successfully to {save_path}\n")
    plt.close()


if __name__ == '__main__':
    model = RTDETR(r"p2.yaml")  # Multi-modal model

    # ==========================================
    # Inject our custom Callbacks into the model
    # ==========================================
    model.add_callback("on_train_epoch_end", on_train_epoch_end)
    model.add_callback("on_train_end", on_train_end)

    # Start training
    model.train(data=r"data.yaml",
                batch=4,
                epochs=200,
                imgsz=640,
                amp=False,
                workers=4,
                optimizer='AdamW',
                lr0=0.001,
                device='0'
                )