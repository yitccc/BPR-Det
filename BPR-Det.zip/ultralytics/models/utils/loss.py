# Ultralytics YOLO 🚀, AGPL-3.0 license

import torch
import torch.nn as nn
import torch.nn.functional as F

from ultralytics.utils.loss import FocalLoss, VarifocalLoss
from ultralytics.utils.metrics import bbox_iou

from .ops import HungarianMatcher


# ==========================================
# [Orthogonal Decoupling] Stage 1 Core: Communication bridge and BNS loss computation
# ==========================================
class BNSContext:
    """Global communication context used to intercept latent variables Q and P_tail from the Head, automatically cleared after Loss computation."""
    queries = []
    p_tails = []
    heads = []

    @classmethod
    def clear(cls):
        cls.queries.clear()
        cls.p_tails.clear()
        cls.heads.clear()


def compute_bns_loss(q_feats, pred_bboxes, gt_bboxes_flat, gt_cls_flat, gt_groups, match_indices, P_tail, tail_classes,
                     gamma_margin=0.5, tau_iou=0.3, tau_bns=0.1, K_neg=10):
    """Partition head, tail, and hard negative sets based on matching results, and compute the hypersphere contrastive loss of Stage 1 from the paper."""
    device = q_feats.device
    B, N, d = q_feats.shape

    gt_idx_offset = 0
    loss_bns_total = 0.0
    all_tail_features = []

    for b in range(B):
        num_gt = int(gt_groups[b])
        b_gt_bboxes = gt_bboxes_flat[gt_idx_offset: gt_idx_offset + num_gt]
        gt_idx_offset += num_gt

        pred_idx, gt_idx = match_indices[b]
        pred_idx = pred_idx.to(device)
        gt_idx = gt_idx.to(device)

        # Align global indices to gt_idx
        matched_labels = gt_cls_flat[gt_idx]
        is_tail = torch.isin(matched_labels, torch.tensor(tail_classes, device=device))

        idx_tail = pred_idx[is_tail]
        idx_head = pred_idx[~is_tail]

        if len(idx_tail) > 0:
            all_tail_features.append(q_feats[b, idx_tail])

        # Get background indices N_bg
        matched_mask = torch.zeros(N, dtype=torch.bool, device=device)
        matched_mask[pred_idx] = True
        bg_idx = torch.where(~matched_mask)[0]

        if len(idx_tail) == 0 or len(bg_idx) == 0:
            continue

        bg_q = q_feats[b, bg_idx]
        bg_bboxes = pred_bboxes[b, bg_idx]

        # 2. Extract hard negatives using joint spatial-semantic constraints
        sim_to_ptail = F.cosine_similarity(bg_q, P_tail, dim=-1)
        semantic_mask = sim_to_ptail > gamma_margin

        if len(b_gt_bboxes) > 0:
            ious = bbox_iou(bg_bboxes.unsqueeze(1), b_gt_bboxes.unsqueeze(0), xywh=True, GIoU=False)
            max_ious, _ = ious.max(dim=1)
            spatial_mask = max_ious.squeeze(-1) < tau_iou
        else:
            spatial_mask = torch.ones_like(semantic_mask)

        # Logical AND and Top-K filtering
        hard_neg_mask = semantic_mask & spatial_mask
        hard_neg_idx_in_bg = torch.where(hard_neg_mask)[0]

        if len(hard_neg_idx_in_bg) > K_neg:
            _, topk_inds = torch.topk(sim_to_ptail[hard_neg_idx_in_bg], K_neg)
            hard_neg_idx_in_bg = hard_neg_idx_in_bg[topk_inds]

        idx_hard_neg = bg_idx[hard_neg_idx_in_bg]

        # 3. Compute contrastive repulsion field L_bns
        Q_tail = q_feats[b, idx_tail]
        Q_head = q_feats[b, idx_head]
        Q_hard_neg = q_feats[b, idx_hard_neg]

        # Must use .detach() to truncate gradients for head and negative queries! Prevents destroying existing features.
        S_neg_queries = torch.cat([Q_head.detach(), Q_hard_neg.detach()], dim=0)

        # Relax temperature tau_bns to 0.5 to prevent exponential explosion causing Loss avalanche
        tau_bns = 0.5

        # Numerator: Pull towards P_tail
        sim_pos = F.cosine_similarity(Q_tail, P_tail, dim=-1) / tau_bns
        num = torch.exp(sim_pos)

        # Denominator: Push away from Head & Hard Negatives
        if len(S_neg_queries) > 0:
            sim_neg = torch.matmul(F.normalize(Q_tail, dim=-1), F.normalize(S_neg_queries, dim=-1).t()) / tau_bns
            S_neg_term = torch.exp(sim_neg).sum(dim=1)
        else:
            S_neg_term = 0.0

        den = num + S_neg_term
        loss_bns_total += -torch.log(num / den).mean()

    tail_feats_cat = torch.cat(all_tail_features, dim=0) if len(all_tail_features) > 0 else None
    return loss_bns_total / max(B, 1), tail_feats_cat


# ==========================================


class DETRLoss(nn.Module):
    """
    DETR (DEtection TRansformer) Loss class.
    """

    def __init__(
            self, nc=80, loss_gain=None, aux_loss=True, use_fl=True, use_vfl=False, use_uni_match=False, uni_match_ind=0
    ):
        super().__init__()

        if loss_gain is None:
            # Add bns coefficient
            loss_gain = {"class": 1, "bbox": 5, "giou": 2, "no_object": 0.1, "mask": 1, "dice": 1, "bns": 0.05}
        self.nc = nc
        self.matcher = HungarianMatcher(cost_gain={"class": 2, "bbox": 5, "giou": 2})
        self.loss_gain = loss_gain
        self.aux_loss = aux_loss
        self.fl = FocalLoss() if use_fl else None
        self.vfl = VarifocalLoss() if use_vfl else None

        self.use_uni_match = use_uni_match
        self.uni_match_ind = uni_match_ind
        self.device = None

    def _get_loss_class(self, pred_scores, targets, gt_scores, num_gts, postfix=""):
        name_class = f"loss_class{postfix}"
        bs, nq = pred_scores.shape[:2]
        one_hot = torch.zeros((bs, nq, self.nc + 1), dtype=torch.int64, device=targets.device)
        one_hot.scatter_(2, targets.unsqueeze(-1), 1)
        one_hot = one_hot[..., :-1]
        gt_scores = gt_scores.view(bs, nq, 1) * one_hot

        if self.fl:
            if num_gts and self.vfl:
                loss_cls = self.vfl(pred_scores, gt_scores, one_hot)
            else:
                loss_cls = self.fl(pred_scores, one_hot.float())
            loss_cls /= max(num_gts, 1) / nq
        else:
            loss_cls = nn.BCEWithLogitsLoss(reduction="none")(pred_scores, gt_scores).mean(1).sum()

        return {name_class: loss_cls.squeeze() * self.loss_gain["class"]}

    def _get_loss_bbox(self, pred_bboxes, gt_bboxes, postfix=""):
        name_bbox = f"loss_bbox{postfix}"
        name_giou = f"loss_giou{postfix}"

        loss = {}
        if len(gt_bboxes) == 0:
            loss[name_bbox] = torch.tensor(0.0, device=self.device)
            loss[name_giou] = torch.tensor(0.0, device=self.device)
            return loss

        loss[name_bbox] = self.loss_gain["bbox"] * F.l1_loss(pred_bboxes, gt_bboxes, reduction="sum") / len(gt_bboxes)
        loss[name_giou] = 1.0 - bbox_iou(pred_bboxes, gt_bboxes, xywh=True, GIoU=True)
        loss[name_giou] = loss[name_giou].sum() / len(gt_bboxes)
        loss[name_giou] = self.loss_gain["giou"] * loss[name_giou]
        return {k: v.squeeze() for k, v in loss.items()}

    def _get_loss_aux(
            self,
            pred_bboxes,
            pred_scores,
            gt_bboxes,
            gt_cls,
            gt_groups,
            match_indices=None,
            postfix="",
            masks=None,
            gt_mask=None,
    ):
        loss = torch.zeros(5 if masks is not None else 3, device=pred_bboxes.device)
        if match_indices is None and self.use_uni_match:
            match_indices = self.matcher(
                pred_bboxes[self.uni_match_ind],
                pred_scores[self.uni_match_ind],
                gt_bboxes,
                gt_cls,
                gt_groups,
                masks=masks[self.uni_match_ind] if masks is not None else None,
                gt_mask=gt_mask,
            )
        for i, (aux_bboxes, aux_scores) in enumerate(zip(pred_bboxes, pred_scores)):
            aux_masks = masks[i] if masks is not None else None
            # Pass layer_idx to identify hierarchical relationships
            loss_ = self._get_loss(
                aux_bboxes,
                aux_scores,
                gt_bboxes,
                gt_cls,
                gt_groups,
                masks=aux_masks,
                gt_mask=gt_mask,
                postfix=postfix,
                match_indices=match_indices,
                layer_idx=i
            )
            loss[0] += loss_[f"loss_class{postfix}"]
            loss[1] += loss_[f"loss_bbox{postfix}"]
            loss[2] += loss_[f"loss_giou{postfix}"]

            # Accumulate BNS Loss of intermediate layers
            if f'loss_bns{postfix}' in loss_:
                if len(loss) == 3: loss = torch.cat([loss, torch.tensor([0.0], device=self.device)])
                loss[-1] += loss_[f"loss_bns{postfix}"]

        ret_loss = {
            f"loss_class_aux{postfix}": loss[0],
            f"loss_bbox_aux{postfix}": loss[1],
            f"loss_giou_aux{postfix}": loss[2],
        }
        if len(loss) > 3:
            ret_loss[f"loss_bns_aux{postfix}"] = loss[-1]
        return ret_loss

    @staticmethod
    def _get_index(match_indices):
        batch_idx = torch.cat([torch.full_like(src, i) for i, (src, _) in enumerate(match_indices)])
        src_idx = torch.cat([src for (src, _) in match_indices])
        dst_idx = torch.cat([dst for (_, dst) in match_indices])
        return (batch_idx, src_idx), dst_idx

    def _get_assigned_bboxes(self, pred_bboxes, gt_bboxes, match_indices):
        pred_assigned = torch.cat(
            [
                t[i] if len(i) > 0 else torch.zeros(0, t.shape[-1], device=self.device)
                for t, (i, _) in zip(pred_bboxes, match_indices)
            ]
        )
        gt_assigned = torch.cat(
            [
                t[j] if len(j) > 0 else torch.zeros(0, t.shape[-1], device=self.device)
                for t, (_, j) in zip(gt_bboxes, match_indices)
            ]
        )
        return pred_assigned, gt_assigned

    def _get_loss(
            self,
            pred_bboxes,
            pred_scores,
            gt_bboxes,
            gt_cls,
            gt_groups,
            masks=None,
            gt_mask=None,
            postfix="",
            match_indices=None,
            layer_idx=None
    ):
        if match_indices is None:
            match_indices = self.matcher(
                pred_bboxes, pred_scores, gt_bboxes, gt_cls, gt_groups, masks=masks, gt_mask=gt_mask
            )

        idx, gt_idx = self._get_index(match_indices)
        pred_bboxes_matched, gt_bboxes_matched = pred_bboxes[idx], gt_bboxes[gt_idx]

        bs, nq = pred_scores.shape[:2]
        targets = torch.full((bs, nq), self.nc, device=pred_scores.device, dtype=gt_cls.dtype)
        targets[idx] = gt_cls[gt_idx]

        gt_scores = torch.zeros([bs, nq], device=pred_scores.device)
        if len(gt_bboxes_matched):
            gt_scores[idx] = bbox_iou(pred_bboxes_matched.detach(), gt_bboxes_matched, xywh=True).squeeze(-1)

        loss = {}
        loss.update(self._get_loss_class(pred_scores, targets, gt_scores, len(gt_bboxes_matched), postfix))
        loss.update(self._get_loss_bbox(pred_bboxes_matched, gt_bboxes_matched, postfix))

        # ==========================================
        # [Orthogonal Decoupling] Execute BNS computation and update EMA
        # ==========================================
        if layer_idx is not None and len(BNSContext.queries) > 0:
            actual_layer_idx = layer_idx if layer_idx != -1 else len(BNSContext.queries) - 1
            if actual_layer_idx < len(BNSContext.queries):
                q_feat = BNSContext.queries[actual_layer_idx]
                P_tail = BNSContext.p_tails[actual_layer_idx]
                head_ref = BNSContext.heads[actual_layer_idx]

                # Slice and align DN and Normal queries tensors
                N_split = pred_bboxes.shape[1]
                if q_feat.shape[1] > N_split:
                    if postfix == "_dn":
                        q_feat = q_feat[:, :N_split, :]
                    else:
                        q_feat = q_feat[:, -N_split:, :]

                # ⚠️ Ensure that 6, 0 here corresponds to the actual long-tailed defect categories in your data.yaml!
                tail_classes = [6, 0]

                bns_loss_val, tail_feats = compute_bns_loss(
                    q_feats=q_feat,
                    pred_bboxes=pred_bboxes,
                    gt_bboxes_flat=gt_bboxes,
                    gt_cls_flat=gt_cls,
                    gt_groups=gt_groups,
                    match_indices=match_indices,
                    P_tail=P_tail,
                    tail_classes=tail_classes
                )

                if isinstance(bns_loss_val, torch.Tensor):
                    loss[f'loss_bns{postfix}'] = bns_loss_val * self.loss_gain.get('bns', 0.05)

                if tail_feats is not None and head_ref.training:
                    head_ref.update_ema_tail(tail_feats, momentum=0.9)
        # ==========================================

        return loss

    def forward(self, pred_bboxes, pred_scores, batch, postfix="", **kwargs):
        self.device = pred_bboxes.device
        match_indices = kwargs.get("match_indices", None)
        gt_cls, gt_bboxes, gt_groups = batch["cls"], batch["bboxes"], batch["gt_groups"]

        total_loss = self._get_loss(
            pred_bboxes[-1], pred_scores[-1], gt_bboxes, gt_cls, gt_groups, postfix=postfix,
            match_indices=match_indices, layer_idx=-1
        )

        if self.aux_loss:
            total_loss.update(
                self._get_loss_aux(
                    pred_bboxes[:-1], pred_scores[:-1], gt_bboxes, gt_cls, gt_groups, match_indices, postfix
                )
            )

        return total_loss


class RTDETRDetectionLoss(DETRLoss):
    """
    Real-Time DeepTracker (RT-DETR) Detection Loss class that extends the DETRLoss.
    """

    def forward(self, preds, batch, dn_bboxes=None, dn_scores=None, dn_meta=None):
        pred_bboxes, pred_scores = preds
        total_loss = super().forward(pred_bboxes, pred_scores, batch)

        if dn_meta is not None:
            dn_pos_idx, dn_num_group = dn_meta["dn_pos_idx"], dn_meta["dn_num_group"]
            assert len(batch["gt_groups"]) == len(dn_pos_idx)

            match_indices = self.get_dn_match_indices(dn_pos_idx, dn_num_group, batch["gt_groups"])

            dn_loss = super().forward(dn_bboxes, dn_scores, batch, postfix="_dn", match_indices=match_indices)
            total_loss.update(dn_loss)
        else:
            total_loss.update({f"{k}_dn": torch.tensor(0.0, device=self.device) for k in total_loss.keys()})

        # 🧹 Clear the communication context to prevent validation set OOM
        BNSContext.clear()

        return total_loss

    @staticmethod
    def get_dn_match_indices(dn_pos_idx, dn_num_group, gt_groups):
        dn_match_indices = []
        idx_groups = torch.as_tensor([0, *gt_groups[:-1]]).cumsum_(0)
        for i, num_gt in enumerate(gt_groups):
            if num_gt > 0:
                gt_idx = torch.arange(end=num_gt, dtype=torch.long) + idx_groups[i]
                gt_idx = gt_idx.repeat(dn_num_group)
                assert len(dn_pos_idx[i]) == len(gt_idx), "Expected the same length, "
                f"but got {len(dn_pos_idx[i])} and {len(gt_idx)} respectively."
                dn_match_indices.append((dn_pos_idx[i], gt_idx))
            else:
                dn_match_indices.append((torch.zeros([0], dtype=torch.long), torch.zeros([0], dtype=torch.long)))
        return dn_match_indices