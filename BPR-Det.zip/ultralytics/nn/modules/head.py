import copy
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.init import constant_, xavier_uniform_

from ultralytics.utils.tal import TORCH_1_10, dist2bbox, dist2rbox, make_anchors

from .block import DFL, BNContrastiveHead, ContrastiveHead, Proto
from .conv import Conv, DWConv
from .transformer import MLP, DeformableTransformerDecoder, DeformableTransformerDecoderLayer
from .utils import bias_init_with_prob, linear_init

# ==========================================
# [Orthogonal Decoupling] Introduce cross-file communication bridge
# ==========================================
try:
    from ultralytics.models.utils.loss import BNSContext
except ImportError:
    # Create a fallback definition to prevent missing modules during network initialization
    class BNSContext:
        queries = []
        p_tails = []
        heads = []

        @classmethod
        def clear(cls):
            cls.queries.clear()
            cls.p_tails.clear()
            cls.heads.clear()

__all__ = "Detect", "Segment", "Pose", "Classify", "OBB", "RTDETRDecoder", "v10Detect"


# ==========================================
# [Orthogonal Decoupling] Stage 2 Core: TCL MoE (Updated)
# ==========================================
class ModalityGate(nn.Module):
    """Spectral-Aware Modality Gate: Strictly matches the Unfold + Patch 2D FFT from the paper"""

    def __init__(self, in_channels, hidden_dim, patch_size=4):
        super().__init__()
        self.patch_size = patch_size
        # Project and align the frequency domain signals of the feature map dimension to the hidden_dim dimension
        self.W_mc = nn.Linear(in_channels, hidden_dim)

    def forward(self, x_features):
        # x_features is a list of 2D multi-scale feature maps from the backbone [ [B, C, H, W], ... ]
        f_v = x_features[0]
        B, C, H, W = f_v.shape

        # 1. Unfold (corresponds to the Unfold operation in the paper) -> [B, C * patch_size * patch_size, L]
        patches = F.unfold(f_v, kernel_size=self.patch_size, stride=self.patch_size)
        L = patches.shape[-1]

        # Reshape into independent Patch structures: [B, C, patch_size, patch_size, L]
        patches = patches.view(B, C, self.patch_size, self.patch_size, L)

        # 2. Perform 2D FFT on each Patch (strictly specify spatial dimensions dim=(2, 3))
        fft_out = torch.fft.rfft2(patches, dim=(2, 3), norm="forward")

        # 3. Extract the amplitude spectrum (corresponds to Phi_amp in the paper)
        phi_amp = torch.abs(fft_out)

        # 4. Aggregate spatial and frequency dimensions -> [B, C]
        # Average over the width and height frequency domain features of the patch, and across all L patches
        sap_freq = phi_amp.mean(dim=(2, 3, 4))

        # 5. Linear projection and Sigmoid gating -> [B, 1, hidden_dim]
        # Adding dimension 1 allows for perfect broadcast multiplication with Transformer Queries [B, N, hidden_dim]
        v_mc = torch.sigmoid(self.W_mc(sap_freq)).unsqueeze(1)
        return v_mc


class MLP_Expert(nn.Module):
    """Two-layer MLP expert network, replacing the single-layer Linear to properly implement MoE"""

    def __init__(self, hidden_dim, num_classes):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, num_classes)
        )

    def forward(self, x):
        return self.mlp(x)


class TCLMoEHead(nn.Module):
    """Trust-Calibrated Mixture-of-Experts routing classification head (adapted for real BNS Loss and EMA updates)"""

    def __init__(self, hidden_dim, num_classes, theta_hard=0.8):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_classes = num_classes
        self.theta_hard = theta_hard
        self.eps = 1e-5

        # Two-layer MLP expert networks
        self.E_head = MLP_Expert(hidden_dim, num_classes)
        self.E_tail = MLP_Expert(hidden_dim, num_classes)

        # ----------------------------------------------------
        # Uncertainty-aware prototypes (Gaussian Distributions)
        # ----------------------------------------------------
        self.P_head = nn.Parameter(torch.randn(1, hidden_dim))

        # [Core Modification] Change P_tail to nn.Parameter, updated in-place via the EMA interface in loss.py
        self.P_tail = nn.Parameter(torch.randn(1, hidden_dim))

        # Covariance (Σ): Diagonal matrix parameterized as a vector, initialized to all 1s (i.e., identity matrix)
        self.Sigma_head = nn.Parameter(torch.ones(1, hidden_dim))
        self.Sigma_tail = nn.Parameter(torch.ones(1, hidden_dim))

        self.tau = nn.Parameter(torch.tensor([5.0]))  # Initial temperature set to 5.0
        self.v_mc = None

    def forward(self, q):
        # q: Queries outputted by Transformer [Batch, N, hidden_dim]
        assert self.v_mc is not None, "Error: v_mc must be injected before forward pass."

        # 1. Modality-aware subspace projection
        q_proj = q * self.v_mc
        mu_head_proj = self.P_head * self.v_mc
        mu_tail_proj = self.P_tail * self.v_mc

        # 2. Apply Softplus and epsilon to ensure strictly positive covariance (avoiding gradient explosion/division by 0)
        sigma_head_pos = F.softplus(self.Sigma_head) * self.v_mc + self.eps
        sigma_tail_pos = F.softplus(self.Sigma_tail) * self.v_mc + self.eps

        # 3. Compute Mahalanobis Distance
        dist_head = (q_proj - mu_head_proj).pow(2) / sigma_head_pos
        s_head = -0.5 * dist_head.sum(dim=-1) - 0.5 * torch.log(sigma_head_pos).sum(dim=-1)  # [Batch, N]

        dist_tail = (q_proj - mu_tail_proj).pow(2) / sigma_tail_pos
        s_tail = -0.5 * dist_tail.sum(dim=-1) - 0.5 * torch.log(sigma_tail_pos).sum(dim=-1)  # [Batch, N]

        # 4. Softmax temperature scaling to generate dynamic routing weights
        scores = torch.stack([s_head, s_tail], dim=-1) / self.tau
        alphas = F.softmax(scores, dim=-1)  # [Batch, N, 2]
        alpha_head, alpha_tail = alphas[..., 0:1], alphas[..., 1:2]

        # 5. Expert output computation and phase discrimination
        if self.training or getattr(self, 'export', False) is False:
            if self.training:
                # [Core Modification] Safely mount current queries, P_tail reference, and head instances to context for loss.py to call
                BNSContext.queries.append(q)
                BNSContext.p_tails.append(self.P_tail)
                BNSContext.heads.append(self)

            # Training and regular evaluation phases: Soft routing joint output
            return alpha_head * self.E_head(q) + alpha_tail * self.E_tail(q)
        else:
            # Inference edge deployment phase: Dynamic hard routing shortcut
            out_head = self.E_head(q)
            out_tail = self.E_tail(q)
            hard_mask = (alpha_head > self.theta_hard).float()
            o_infer = hard_mask * out_head + (1 - hard_mask) * (alpha_head * out_head + alpha_tail * out_tail)
            return o_infer

    def update_ema_tail(self, tail_features, momentum=0.9):
        """EMA momentum update interface (safely triggered by BNS computation logic in loss.py)"""
        if tail_features.numel() > 0:
            tail_mean = tail_features.mean(dim=0, keepdim=True).detach()
            # Cold start protection: If standard deviation is too large, indicating random initialization stage, directly align with current mean
            with torch.no_grad():
                if torch.std(self.P_tail) > 0.5:
                    self.P_tail.data.copy_(tail_mean)
                else:
                    self.P_tail.data.copy_(momentum * self.P_tail.data + (1.0 - momentum) * tail_mean)


# ==========================================


class Detect(nn.Module):
    # [Original code remains unchanged, omitted here to save space...]
    pass


class Segment(Detect):
    # [Original code remains unchanged, omitted here to save space...]
    pass


class OBB(Detect):
    # [Original code remains unchanged, omitted here to save space...]
    pass


class Pose(Detect):
    # [Original code remains unchanged, omitted here to save space...]
    pass


class Classify(nn.Module):
    # [Original code remains unchanged, omitted here to save space...]
    pass


class WorldDetect(Detect):
    # [Original code remains unchanged, omitted here to save space...]
    pass


class RTDETRDecoder(nn.Module):
    """
    Real-Time Deformable Transformer Decoder (RTDETRDecoder) module for object detection.
    """

    export = False  # export mode

    def __init__(
            self,
            nc=80,
            ch=(512, 1024, 2048),
            hd=256,  # hidden dim
            nq=300,  # num queries
            ndp=4,  # num decoder points
            nh=8,  # num head
            ndl=6,  # num decoder layers
            d_ffn=1024,  # dim of feedforward
            dropout=0.0,
            act=nn.ReLU(),
            eval_idx=-1,
            # Training args
            nd=100,  # num denoising
            label_noise_ratio=0.5,
            box_noise_scale=1.0,
            learnt_init_query=False,
    ):
        super().__init__()
        self.hidden_dim = hd
        self.nhead = nh
        self.nl = len(ch)  # num level
        self.nc = nc
        self.num_queries = nq
        self.num_decoder_layers = ndl

        # Backbone feature projection
        self.input_proj = nn.ModuleList(nn.Sequential(nn.Conv2d(x, hd, 1, bias=False), nn.BatchNorm2d(hd)) for x in ch)

        # Transformer module
        decoder_layer = DeformableTransformerDecoderLayer(hd, nh, d_ffn, dropout, act, self.nl, ndp)
        self.decoder = DeformableTransformerDecoder(hd, decoder_layer, ndl, eval_idx)

        # Denoising part
        self.denoising_class_embed = nn.Embedding(nc, hd)
        self.num_denoising = nd
        self.label_noise_ratio = label_noise_ratio
        self.box_noise_scale = box_noise_scale

        # Decoder embedding
        self.learnt_init_query = learnt_init_query
        if learnt_init_query:
            self.tgt_embed = nn.Embedding(nq, hd)
        self.query_pos_head = MLP(4, 2 * hd, hd, num_layers=2)

        # Encoder head
        self.enc_output = nn.Sequential(nn.Linear(hd, hd), nn.LayerNorm(hd))
        self.enc_score_head = nn.Linear(hd, nc)
        self.enc_bbox_head = MLP(hd, hd, 4, num_layers=3)

        # ==========================================
        # [Orthogonal Decoupling] Decoder head initialization
        # ==========================================
        self.modality_gate = ModalityGate(in_channels=ch[0], hidden_dim=hd)
        self.dec_score_head = nn.ModuleList([TCLMoEHead(hd, nc) for _ in range(ndl)])
        self.dec_bbox_head = nn.ModuleList([MLP(hd, hd, 4, num_layers=3) for _ in range(ndl)])

        self._reset_parameters()

    def forward(self, x, batch=None):
        """Runs the forward pass of the module, returning bounding box and classification scores for the input."""
        from ultralytics.models.utils.ops import get_cdn_group

        # Input projection and embedding
        feats, shapes = self._get_encoder_input(x)

        # Prepare denoising training
        dn_embed, dn_bbox, attn_mask, dn_meta = get_cdn_group(
            batch,
            self.nc,
            self.num_queries,
            self.denoising_class_embed.weight,
            self.num_denoising,
            self.label_noise_ratio,
            self.box_noise_scale,
            self.training,
        )

        embed, refer_bbox, enc_bboxes, enc_scores = self._get_decoder_input(feats, shapes, dn_embed, dn_bbox)

        # ---> [Inject cross-modal frequency domain gating (Unfold 2D FFT)] <---
        # Directly pass the unflattened 2D feature map list x
        v_mc = self.modality_gate(x)
        for score_head in self.dec_score_head:
            score_head.v_mc = v_mc

        # Decoder
        dec_bboxes, dec_scores = self.decoder(
            embed,
            refer_bbox,
            feats,
            shapes,
            self.dec_bbox_head,
            self.dec_score_head,
            self.query_pos_head,
            attn_mask=attn_mask,
        )
        x = dec_bboxes, dec_scores, enc_bboxes, enc_scores, dn_meta
        if self.training:
            return x
        # (bs, 300, 4+nc)
        y = torch.cat((dec_bboxes.squeeze(0), dec_scores.squeeze(0).sigmoid()), -1)
        return y if self.export else (y, x)

    def _generate_anchors(self, shapes, grid_size=0.05, dtype=torch.float32, device="cpu", eps=1e-2):
        """Generates anchor bounding boxes for given shapes with specific grid size and validates them."""
        anchors = []
        for i, (h, w) in enumerate(shapes):
            sy = torch.arange(end=h, dtype=dtype, device=device)
            sx = torch.arange(end=w, dtype=dtype, device=device)
            grid_y, grid_x = torch.meshgrid(sy, sx, indexing="ij") if TORCH_1_10 else torch.meshgrid(sy, sx)
            grid_xy = torch.stack([grid_x, grid_y], -1)  # (h, w, 2)

            valid_WH = torch.tensor([w, h], dtype=dtype, device=device)
            grid_xy = (grid_xy.unsqueeze(0) + 0.5) / valid_WH  # (1, h, w, 2)
            wh = torch.ones_like(grid_xy, dtype=dtype, device=device) * grid_size * (2.0 ** i)
            anchors.append(torch.cat([grid_xy, wh], -1).view(-1, h * w, 4))  # (1, h*w, 4)

        anchors = torch.cat(anchors, 1)  # (1, h*w*nl, 4)
        valid_mask = ((anchors > eps) & (anchors < 1 - eps)).all(-1, keepdim=True)  # 1, h*w*nl, 1
        anchors = torch.log(anchors / (1 - anchors))
        anchors = anchors.masked_fill(~valid_mask, float("inf"))
        return anchors, valid_mask

    def _get_encoder_input(self, x):
        """Processes and returns encoder inputs by getting projection features from input and concatenating them."""
        # Get projection features
        x = [self.input_proj[i](feat) for i, feat in enumerate(x)]
        # Get encoder inputs
        feats = []
        shapes = []
        for feat in x:
            h, w = feat.shape[2:]
            # [b, c, h, w] -> [b, h*w, c]
            feats.append(feat.flatten(2).permute(0, 2, 1))
            # [nl, 2]
            shapes.append([h, w])

        # [b, h*w, c]
        feats = torch.cat(feats, 1)
        return feats, shapes

    def _get_decoder_input(self, feats, shapes, dn_embed=None, dn_bbox=None):
        """Generates and prepares the input required for the decoder from the provided features and shapes."""
        bs = feats.shape[0]
        # Prepare input for decoder
        anchors, valid_mask = self._generate_anchors(shapes, dtype=feats.dtype, device=feats.device)
        features = self.enc_output(valid_mask * feats)  # bs, h*w, 256

        enc_outputs_scores = self.enc_score_head(features)  # (bs, h*w, nc)

        # Query selection
        # (bs, num_queries)
        topk_ind = torch.topk(enc_outputs_scores.max(-1).values, self.num_queries, dim=1).indices.view(-1)
        # (bs, num_queries)
        batch_ind = torch.arange(end=bs, dtype=topk_ind.dtype).unsqueeze(-1).repeat(1, self.num_queries).view(-1)

        # (bs, num_queries, 256)
        top_k_features = features[batch_ind, topk_ind].view(bs, self.num_queries, -1)
        # (bs, num_queries, 4)
        top_k_anchors = anchors[:, topk_ind].view(bs, self.num_queries, -1)

        # Dynamic anchors + static content
        refer_bbox = self.enc_bbox_head(top_k_features) + top_k_anchors

        enc_bboxes = refer_bbox.sigmoid()
        if dn_bbox is not None:
            refer_bbox = torch.cat([dn_bbox, refer_bbox], 1)
        enc_scores = enc_outputs_scores[batch_ind, topk_ind].view(bs, self.num_queries, -1)

        embeddings = self.tgt_embed.weight.unsqueeze(0).repeat(bs, 1, 1) if self.learnt_init_query else top_k_features
        if self.training:
            refer_bbox = refer_bbox.detach()
            if not self.learnt_init_query:
                embeddings = embeddings.detach()
        if dn_embed is not None:
            embeddings = torch.cat([dn_embed, embeddings], 1)

        return embeddings, refer_bbox, enc_bboxes, enc_scores

    def _reset_parameters(self):
        """Initializes or resets the parameters of the model's various components with predefined weights and biases."""
        # Class and bbox head init
        bias_cls = bias_init_with_prob(0.01) / 80 * self.nc

        constant_(self.enc_score_head.bias, bias_cls)
        constant_(self.enc_bbox_head.layers[-1].weight, 0.0)
        constant_(self.enc_bbox_head.layers[-1].bias, 0.0)

        for cls_, reg_ in zip(self.dec_score_head, self.dec_bbox_head):
            # [Core Fix] Initialize the bias of the terminal classification layer of the dual expert networks (pointing to the last layer of MLP)
            constant_(cls_.E_head.mlp[-1].bias, bias_cls)
            constant_(cls_.E_tail.mlp[-1].bias, bias_cls)
            constant_(reg_.layers[-1].weight, 0.0)
            constant_(reg_.layers[-1].bias, 0.0)

        linear_init(self.enc_output[0])
        xavier_uniform_(self.enc_output[0].weight)
        if self.learnt_init_query:
            xavier_uniform_(self.tgt_embed.weight)
        xavier_uniform_(self.query_pos_head.layers[0].weight)
        xavier_uniform_(self.query_pos_head.layers[1].weight)
        for layer in self.input_proj:
            xavier_uniform_(layer[0].weight)

class v10Detect(Detect):


    end2end = True

    def __init__(self, nc=80, ch=()):
        """Initializes the v10Detect object with the specified number of classes and input channels."""
        super().__init__(nc, ch)
        c3 = max(ch[0], min(self.nc, 100))  # channels
        # Light cls head
        self.cv3 = nn.ModuleList(
            nn.Sequential(
                nn.Sequential(Conv(x, x, 3, g=x), Conv(x, c3, 1)),
                nn.Sequential(Conv(c3, c3, 3, g=c3), Conv(c3, c3, 1)),
                nn.Conv2d(c3, self.nc, 1),
            )
            for x in ch
        )
        self.one2one_cv3 = copy.deepcopy(self.cv3)